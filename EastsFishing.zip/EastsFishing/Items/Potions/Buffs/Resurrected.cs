using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class Resurrected : ModBuff
    {
        public override void SetDefaults()
        {
            Main.debuff[Type] = true;
            Main.buffNoSave[Type] = false;			
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Resurrected");
			Description.SetDefault("You can't be affected by holy potion");
        }
        public override void Update(Player player, ref int buffIndex)
        {
			player.ClearBuff(mod.BuffType("Holy"));
		}
    }
}