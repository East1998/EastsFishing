using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;
namespace EastsFishing.Items.Potions.Buffs
{
    public class Snowbreath : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Snowbreath");
			Description.SetDefault("You will randomly shoot ice projectiles at your enemies");
        }
        public override void Update(Player player, ref int buffIndex)
        {
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Oceanbreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Snowbreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Flamebreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Snowbreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Skybreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Snowbreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Sandbreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Snowbreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Junglebreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Snowbreath"));
			}
        }
	}
}