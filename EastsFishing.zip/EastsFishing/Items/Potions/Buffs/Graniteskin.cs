using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class Graniteskin : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Graniteskin");
			Description.SetDefault("Increase defense by 16, overrides Ironskin");
        }
        public override void Update(Player player, ref int buffIndex)
        {	
			player.statDefense += 16;
			if (Main.LocalPlayer.FindBuffIndex(5) > -1)
			{
				player.ClearBuff(5);
			}
        }
    }
}