using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class Constitution : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Constitution");
			Description.SetDefault("Max health increased by 50");
        }
        public override void Update(Player player, ref int buffIndex)
        {
			player.statLifeMax2 += 50;
			if (Main.LocalPlayer.FindBuffIndex(113) > -1)
			{
				player.statLifeMax2 += 10;			
			}
        }
    }
}