using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class MarbleSwiftness : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("MarbleSwiftness");
			Description.SetDefault("50% increased movement speed, overrides Swiftness");
        }
        public override void Update(Player player, ref int buffIndex)
        {	
			player.moveSpeed += 0.5f;
			if (Main.LocalPlayer.FindBuffIndex(3) > -1)
			{
				player.ClearBuff(3);
			}
        }
    }
}