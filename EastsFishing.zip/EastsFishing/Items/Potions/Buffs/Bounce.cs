using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class Bounce : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Bouncy!");
			Description.SetDefault("Negates fall damage");
        }
        public override void Update(Player player, ref int buffIndex)
        {
            player.noFallDmg = true;
        }
    }
}