using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class Holy : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Holy");
			Description.SetDefault("Cheat death once");
        }
        public override void Update(Player player, ref int buffIndex)
        {
			((EastsFishingGlobalPlayer)player.GetModPlayer(mod, "EastsFishingGlobalPlayer")).holyPotion= true;
		}
    }
}