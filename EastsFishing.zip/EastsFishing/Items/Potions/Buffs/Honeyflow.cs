using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;

namespace EastsFishing.Items.Potions.Buffs
{
    public class Honeyflow : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Honeyflow");
			Description.SetDefault("Increase honey regeneration effectiveness");
        }
        public override void Update(Player player, ref int buffIndex)
        {
			if (Main.LocalPlayer.FindBuffIndex(48) > -1)
			{	
				player.lifeRegen += 3;				
			}
		}
    }
}