using System.Collections.Generic;
using Terraria;
using System.Collections.Generic;
using System;
using Terraria;
using Terraria.ID;
using Terraria.ModLoader;
using Microsoft.Xna.Framework;
using System.Diagnostics;
using Microsoft.Xna.Framework.Graphics;
namespace EastsFishing.Items.Potions.Buffs
{
    public class Junglebreath : ModBuff
    {
        public override void SetDefaults()
        {
            Main.buffNoTimeDisplay[Type] = false;
			DisplayName.SetDefault("Junglebreath");
			Description.SetDefault("You will randomly shoot jungle projectiles at your enemies");
        }
        public override void Update(Player player, ref int buffIndex)
        {
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Oceanbreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Junglebreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Flamebreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Junglebreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Skybreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Junglebreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Sandbreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Junglebreath"));
			}
			if (Main.LocalPlayer.FindBuffIndex(mod.BuffType("Snowbreath")) > -1)
			{
				player.ClearBuff(mod.BuffType("Junglebreath"));
			}
        }
	}
}